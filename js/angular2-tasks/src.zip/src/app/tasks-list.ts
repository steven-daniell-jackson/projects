export class TasksList {
  clientName: string;
}
