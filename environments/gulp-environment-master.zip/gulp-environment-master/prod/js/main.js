
$("section").click(function(){

	$(this).find("p").slideToggle();
});

// $("p").hide();
